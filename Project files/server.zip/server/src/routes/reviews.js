const express = require('express');
const router = express.Router();
const Review = require('../models/Review');
const auth = require('../middleware/auth');

// Get reviews for a book
router.get('/book/:bookId', async (req, res) => {
  try {
    const reviews = await Review.find({ book: req.params.bookId })
      .populate({ path: 'author', select: 'name email' })
      .sort({ createdAt: -1 });
    res.json(reviews);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Create a review
router.post('/', auth, async (req, res) => {
  try {
    const { bookId, rating, title, comment } = req.body;
    if (!bookId || !rating) {
      return res.status(400).json({ message: 'Missing required fields' });
    }

    // Check if user already reviewed this book
    const existing = await Review.findOne({ book: bookId, author: req.user.id });
    if (existing) {
      return res.status(400).json({ message: 'You have already reviewed this book' });
    }

    const review = new Review({
      book: bookId,
      author: req.user.id,
      rating,
      title,
      comment
    });

    await review.save();
    await review.populate({ path: 'author', select: 'name email' });
    res.json(review);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Update review
router.put('/:id', auth, async (req, res) => {
  try {
    const review = await Review.findById(req.params.id);
    if (!review) return res.status(404).json({ message: 'Review not found' });

    if (review.author.toString() !== req.user.id) {
      return res.status(403).json({ message: 'Forbidden' });
    }

    const { rating, title, comment } = req.body;
    if (rating) review.rating = rating;
    if (title) review.title = title;
    if (comment) review.comment = comment;

    await review.save();
    res.json(review);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Delete review
router.delete('/:id', auth, async (req, res) => {
  try {
    const review = await Review.findById(req.params.id);
    if (!review) return res.status(404).json({ message: 'Review not found' });

    if (review.author.toString() !== req.user.id) {
      return res.status(403).json({ message: 'Forbidden' });
    }

    await review.deleteOne();
    res.json({ message: 'Deleted' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
