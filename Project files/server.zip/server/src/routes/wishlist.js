const express = require('express');
const router = express.Router();
const Wishlist = require('../models/Wishlist');
const auth = require('../middleware/auth');

// Get user's wishlist
router.get('/', auth, async (req, res) => {
  try {
    const wishlist = await Wishlist.find({ user: req.user.id })
      .populate('book')
      .sort({ createdAt: -1 });
    res.json(wishlist);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Add to wishlist
router.post('/', auth, async (req, res) => {
  try {
    const { bookId } = req.body;
    if (!bookId) {
      return res.status(400).json({ message: 'BookId required' });
    }

    // Check if already in wishlist
    const existing = await Wishlist.findOne({ user: req.user.id, book: bookId });
    if (existing) {
      return res.status(400).json({ message: 'Already in wishlist' });
    }

    const wishlist = new Wishlist({ user: req.user.id, book: bookId });
    await wishlist.save();
    await wishlist.populate('book');
    res.json(wishlist);
  } catch (err) {
    if (err.code === 11000) {
      return res.status(400).json({ message: 'Already in wishlist' });
    }
    res.status(500).json({ error: err.message });
  }
});

// Remove from wishlist
router.delete('/:bookId', auth, async (req, res) => {
  try {
    const wishlist = await Wishlist.findOneAndDelete({
      user: req.user.id,
      book: req.params.bookId
    });
    if (!wishlist) return res.status(404).json({ message: 'Not in wishlist' });
    res.json({ message: 'Removed from wishlist' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
