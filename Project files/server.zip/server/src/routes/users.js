const express = require('express')
const router = express.Router()
const User = require('../models/User')
const auth = require('../middleware/auth')
const bcrypt = require('bcrypt')
const requireRole = require('../middleware/roles')

// GET current user's profile
router.get('/me', auth, async (req, res) => {
  try {
    const user = await User.findById(req.user.id).select('-passwordHash')
    if (!user) return res.status(404).json({ message: 'User not found' })
    res.json(user)
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// Admin: list all users (no password hashes)
router.get('/', auth, requireRole('admin'), async (req, res) => {
  try {
    const users = await User.find().select('-passwordHash').limit(1000)
    res.json(users)
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// Update current user's profile (name, email, password)
router.put('/me', auth, async (req, res) => {
  try {
    const { name, email, password } = req.body
    const user = await User.findById(req.user.id)
    if (!user) return res.status(404).json({ message: 'User not found' })
    if (name) user.name = name
    if (email) user.email = email
    if (password) user.passwordHash = await bcrypt.hash(password, 10)
    await user.save()
    const out = user.toObject()
    delete out.passwordHash
    res.json(out)
  } catch (err) {
    // handle duplicate email error
    if (err.code === 11000) return res.status(400).json({ message: 'Email already in use' })
    res.status(500).json({ error: err.message })
  }
})

// Admin: change role of a user
router.put('/:id/role', auth, requireRole('admin'), async (req, res) => {
  try {
    const { role } = req.body
    const allowed = ['user', 'seller', 'admin']
    if (!allowed.includes(role)) return res.status(400).json({ message: 'Invalid role' })
    const user = await User.findById(req.params.id)
    if (!user) return res.status(404).json({ message: 'User not found' })
    user.role = role
    await user.save()
    res.json({ id: user._id, role: user.role })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// Admin: delete a user
router.delete('/:id', auth, requireRole('admin'), async (req, res) => {
  try {
    const user = await User.findById(req.params.id)
    if (!user) return res.status(404).json({ message: 'User not found' })
    await user.deleteOne()
    res.json({ message: 'User deleted' })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

module.exports = router
