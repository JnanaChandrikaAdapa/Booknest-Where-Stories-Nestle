const express = require('express');
const router = express.Router();
const Order = require('../models/Order');
const Book = require('../models/Book');
const auth = require('../middleware/auth');
const requireRole = require('../middleware/roles');

// Get all orders (admin only)
router.get('/', auth, requireRole('admin'), async (req, res) => {
  try {
    const orders = await Order.find()
      .populate('book')
      .populate('buyer')
      .populate('seller')
      .sort({ bookingDate: -1 });
    res.json(orders);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Create an order
router.post('/', auth, async (req, res) => {
  try {
    const { bookId, quantity, shippingAddress } = req.body;
    if (!bookId || !quantity || !shippingAddress) {
      return res.status(400).json({ message: 'Missing required fields' });
    }

    const book = await Book.findById(bookId).populate('createdBy');
    if (!book) return res.status(404).json({ message: 'Book not found' });

    const totalPrice = book.price * quantity;
    const order = new Order({
      buyer: req.user.id,
      seller: book.createdBy._id,
      book: bookId,
      quantity,
      totalPrice,
      shippingAddress
    });

    await order.save();
    await order.populate(['buyer', 'seller', 'book']);
    res.json(order);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get user's orders (buyer view)
router.get('/my-orders', auth, async (req, res) => {
  try {
    const orders = await Order.find({ buyer: req.user.id })
      .populate('book')
      .populate({ path: 'seller', select: '-passwordHash' })
      .sort({ bookingDate: -1 });
    res.json(orders);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get seller's orders (seller view)
router.get('/seller-orders', auth, requireRole('seller'), async (req, res) => {
  try {
    const orders = await Order.find({ seller: req.user.id })
      .populate('book')
      .populate({ path: 'buyer', select: '-passwordHash' })
      .sort({ bookingDate: -1 });
    res.json(orders);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get single order
router.get('/:id', auth, async (req, res) => {
  try {
    const order = await Order.findById(req.params.id)
      .populate('book')
      .populate('buyer')
      .populate('seller');
    if (!order) return res.status(404).json({ message: 'Order not found' });

    // Check if user is buyer or seller
    if (order.buyer._id.toString() !== req.user.id && order.seller._id.toString() !== req.user.id) {
      return res.status(403).json({ message: 'Forbidden' });
    }

    res.json(order);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Update order status (seller only)
router.put('/:id/status', auth, requireRole('seller'), async (req, res) => {
  try {
    const { status } = req.body;
    const allowed = ['pending', 'shipped', 'delivered', 'cancelled'];
    if (!allowed.includes(status)) return res.status(400).json({ message: 'Invalid status' });

    const order = await Order.findById(req.params.id);
    if (!order) return res.status(404).json({ message: 'Order not found' });

    // Check if user is the seller
    if (order.seller.toString() !== req.user.id) {
      return res.status(403).json({ message: 'Forbidden' });
    }

    order.status = status;
    if (status === 'delivered') {
      order.deliveryDate = new Date();
    }
    await order.save();
    res.json(order);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
