const express = require('express');
const router = express.Router();
const Book = require('../models/Book');
const auth = require('../middleware/auth');
const requireRole = require('../middleware/roles');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

// Use absolute path for uploads directory
let uploadDir = process.env.UPLOAD_DIR || path.resolve(__dirname, '../../uploads');
// Ensure it's an absolute path
if (!path.isAbsolute(uploadDir)) {
  uploadDir = path.resolve(__dirname, '../../uploads');
}
console.log('Books route upload directory:', uploadDir);
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
  console.log('Created upload directory:', uploadDir);
}

const storage = multer.diskStorage({
  destination: function (req, file, cb) { 
    console.log('[Multer] Saving file to:', uploadDir);
    cb(null, uploadDir) 
  },
  filename: function (req, file, cb) {
    const ext = path.extname(file.originalname);
    const filename = Date.now() + ext;
    console.log('[Multer] Generated filename:', filename, 'Original:', file.originalname);
    cb(null, filename);
  }
});

const upload = multer({ 
  storage: storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit
  fileFilter: function (req, file, cb) {
    console.log('[Multer] File received:', file.originalname, 'Size:', file.size);
    const validMimes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    if (validMimes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type. Only images allowed.'));
    }
  }
})

// list with simple text search
router.get('/', async (req, res) => {
  try {
    const { q } = req.query;
    const filter = q ? { $text: { $search: q } } : {};
    const books = await Book.find(filter).limit(200);
    res.json(books);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// get single
router.get('/:id', async (req, res) => {
  try {
    const book = await Book.findById(req.params.id);
    if (!book) return res.status(404).json({ message: 'Book not found' });
    res.json(book);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// create (protected, sellers/admin) - supports cover file upload (form-data)
router.post('/', auth, requireRole('seller'), upload.single('cover'), async (req, res) => {
  try {
    const { title, authors, genres, description, price } = req.body;
    if (!title) return res.status(400).json({ message: 'Title required' });
    const bookData = {
      title,
      authors: authors ? authors.split(',').map(s=>s.trim()) : [],
      genres: genres ? genres.split(',').map(s=>s.trim()) : [],
      description,
      price: price ? Number(price) : 0,
      createdBy: req.user.id
    }
    if (req.file) {
      const relativePath = `/uploads/${req.file.filename}`;
      bookData.coverUrl = relativePath;
      console.log('[Book Create] File uploaded successfully');
      console.log('[Book Create] File destination:', req.file.destination);
      console.log('[Book Create] File path:', req.file.path);
      console.log('[Book Create] Stored cover URL:', relativePath);
      // Verify file exists
      if (fs.existsSync(req.file.path)) {
        console.log('[Book Create] ✓ File verified on disk');
      } else {
        console.warn('[Book Create] ✗ File NOT found on disk:', req.file.path);
      }
    }
    const book = new Book(bookData);
    await book.save();
    res.json(book);
  } catch (err) {
    console.error('Error creating book:', err);
    res.status(500).json({ error: err.message });
  }
});

// update (protected, only by creator or admin)
router.put('/:id', auth, requireRole('seller'), upload.single('cover'), async (req, res) => {
  try {
    const book = await Book.findById(req.params.id);
    if (!book) return res.status(404).json({ message: 'Book not found' });
    
    // Only allow if user is the creator or is admin
    if (book.createdBy.toString() !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'You can only edit your own books' });
    }
    
    const { title, authors, genres, description, price } = req.body;
    if (title) book.title = title;
    if (authors) book.authors = authors.split(',').map(s=>s.trim());
    if (genres) book.genres = genres.split(',').map(s=>s.trim());
    if (description) book.description = description;
    if (price) book.price = Number(price);
    if (req.file) {
      // delete old cover if exists and is local
      if (book.coverUrl && book.coverUrl.startsWith('/uploads/')){
        const oldPath = path.join(__dirname, '../../', book.coverUrl)
        try{ 
          fs.unlinkSync(oldPath);
          console.log('Deleted old cover:', oldPath);
        }catch(e){
          console.warn('Could not delete old cover:', e.message);
        }
      }
      const newCoverUrl = `/uploads/${req.file.filename}`;
      book.coverUrl = newCoverUrl;
      console.log('File updated:', req.file.filename);
      console.log('New cover URL:', newCoverUrl);
    }
    await book.save();
    res.json(book);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// delete (protected, only by creator or admin)
router.delete('/:id', auth, requireRole('seller'), async (req, res) => {
  try {
    const book = await Book.findById(req.params.id);
    if (!book) return res.status(404).json({ message: 'Book not found' });
    
    // Only allow if user is the creator or is admin
    if (book.createdBy.toString() !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'You can only delete your own books' });
    }
    
    if (book.coverUrl && book.coverUrl.startsWith('/uploads/')){
      const oldPath = path.join(__dirname, '../../', book.coverUrl)
      try{ fs.unlinkSync(oldPath) }catch(e){}
    }
    await book.deleteOne();
    res.json({ message: 'Deleted' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
