const mongoose = require('mongoose');

const BookSchema = new mongoose.Schema({
  title: { type: String, required: true },
  authors: [{ type: String }],
  genres: [{ type: String }],
  description: String,
  price: { type: Number, default: 0 },
  coverUrl: String,
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  createdAt: { type: Date, default: Date.now }
});

// text index for simple search
BookSchema.index({ title: 'text', description: 'text', authors: 'text' });

module.exports = mongoose.model('Book', BookSchema);
