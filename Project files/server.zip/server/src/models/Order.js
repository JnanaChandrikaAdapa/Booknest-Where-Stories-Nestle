const mongoose = require('mongoose');

const OrderSchema = new mongoose.Schema({
  buyer: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  seller: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  book: { type: mongoose.Schema.Types.ObjectId, ref: 'Book', required: true },
  quantity: { type: Number, default: 1, min: 1 },
  totalPrice: { type: Number, required: true },
  shippingAddress: { type: String },
  status: { type: String, enum: ['pending', 'shipped', 'delivered', 'cancelled'], default: 'pending' },
  bookingDate: { type: Date, default: Date.now },
  deliveryDate: Date,
  warranty: String,
  notes: String
});

module.exports = mongoose.model('Order', OrderSchema);
