const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const mongoose = require('mongoose');
const path = require('path');
const fs = require('fs');

dotenv.config();
const app = express();

// Setup uploads directory - use absolute path
const uploadsDir = path.resolve(__dirname, '../../uploads');
console.log('Setting up uploads directory:', uploadsDir);
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
  console.log('Created uploads directory');
}

// CORS setup
app.use(cors({
  origin: ['http://localhost:5173', 'http://localhost:3000', 'http://localhost:5000'],
  credentials: true
}));

// Body parser - JSON
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Custom image serving route with proper headers
app.get('/uploads/:filename', (req, res) => {
  const filename = req.params.filename;
  const filepath = path.join(uploadsDir, filename);
  
  // Security: prevent directory traversal
  if (!path.resolve(filepath).startsWith(path.resolve(uploadsDir))) {
    return res.status(403).json({ error: 'Forbidden' });
  }
  
  // Check if file exists
  if (!fs.existsSync(filepath)) {
    console.log('[Image] File not found:', filepath);
    return res.status(404).json({ error: 'Image not found' });
  }
  
  // Set proper headers
  res.setHeader('Cache-Control', 'public, max-age=3600');
  res.setHeader('Access-Control-Allow-Origin', '*');
  
  // Send the file
  res.sendFile(filepath);
});

console.log('Image serving route configured for:', uploadsDir);

// Test endpoint to check uploads folder
app.get('/api/test/uploads', (req, res) => {
  try {
    const files = fs.readdirSync(uploadsDir);
    res.json({
      path: uploadsDir,
      exists: true,
      fileCount: files.length,
      files: files.slice(0, 10) // first 10 files
    });
  } catch (err) {
    res.json({
      path: uploadsDir,
      exists: false,
      error: err.message
    });
  }
});

// connect to mongo
const mongoUri = process.env.MONGO_URI || 'mongodb://localhost:27017/booknest';
mongoose.connect(mongoUri, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.error('MongoDB connection error:', err));

// routes (will create files if they don't exist)
try {
  app.use('/api/auth', require('./routes/auth'));
} catch (e) {
  console.warn('Auth routes missing:', e.message);
}

try {
  app.use('/api/books', require('./routes/books'));
} catch (e) {
  console.warn('Books routes missing:', e.message);
}

try {
  app.use('/api/users', require('./routes/users'));
} catch (e) {
  console.warn('Users routes missing:', e.message);
}

try {
  app.use('/api/orders', require('./routes/orders'));
} catch (e) {
  console.warn('Orders routes missing:', e.message);
}

try {
  app.use('/api/reviews', require('./routes/reviews'));
} catch (e) {
  console.warn('Reviews routes missing:', e.message);
}

try {
  app.use('/api/wishlist', require('./routes/wishlist'));
} catch (e) {
  console.warn('Wishlist routes missing:', e.message);
}

const PORT = process.env.PORT || 5000;

// Log upload folder info
console.log('Uploads folder path:', path.join(__dirname, '../../uploads'));
console.log('Uploads folder exists:', require('fs').existsSync(path.join(__dirname, '../../uploads')));

app.listen(PORT, () => console.log(`Server started on port ${PORT}`));
