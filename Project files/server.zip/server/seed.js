#!/usr/bin/env node

/**
 * Test Data Seeding Script for BookNest
 * Creates test accounts for user, seller, and admin roles
 */

const axios = require('axios');
const mongoose = require('mongoose');

const API_URL = 'http://localhost:5000/api';
const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/booknest';

// Test account credentials
const testAccounts = [
  {
    name: 'Regular User',
    email: 'user@booknest.com',
    password: 'password123',
    targetRole: 'user'
  },
  {
    name: 'Seller Account',
    email: 'seller@booknest.com',
    password: 'password123',
    targetRole: 'seller'
  },
  {
    name: 'Admin Account',
    email: 'admin@booknest.com',
    password: 'password123',
    targetRole: 'admin'
  }
];

async function seedTestData() {
  try {
    console.log('🌱 Starting test data seeding...\n');

    // Connect to MongoDB
    await mongoose.connect(MONGO_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true
    });
    console.log('✅ Connected to MongoDB\n');

    const User = require('./src/models/User');

    for (const account of testAccounts) {
      try {
        // Check if user already exists
        const existing = await User.findOne({ email: account.email });

        if (existing) {
          console.log(`⏭️  User ${account.email} already exists (role: ${existing.role})`);
          continue;
        }

        // Register via API first
        const registerRes = await axios.post(`${API_URL}/auth/register`, {
          name: account.name,
          email: account.email,
          password: account.password
        });

        console.log(`✅ Registered: ${account.name} (${account.email})`);

        // If targeting seller or admin, update role in DB directly
        if (account.targetRole !== 'user') {
          const user = await User.findOne({ email: account.email });
          user.role = account.targetRole;
          await user.save();
          console.log(`⬆️  Promoted to ${account.targetRole} role\n`);
        } else {
          console.log(`   Role: ${account.targetRole}\n`);
        }
      } catch (err) {
        console.error(`❌ Error creating ${account.email}:`, err.response?.data || err.message);
      }
    }

    console.log('\n📋 Test Account Summary:');
    console.log('=' .repeat(60));

    for (const account of testAccounts) {
      const user = await User.findOne({ email: account.email });
      if (user) {
        console.log(`\n📧 Email: ${account.email}`);
        console.log(`🔐 Password: ${account.password}`);
        console.log(`👤 Role: ${user.role}`);
        console.log(`📍 ID: ${user._id}`);
      }
    }

    console.log('\n' + '='.repeat(60));
    console.log('✅ Test data seeding complete!\n');

    console.log('🌐 Access the app at: http://localhost:5173\n');
    console.log('Login Credentials:');
    console.log('  USER:  user@booknest.com / password123');
    console.log('  SELLER: seller@booknest.com / password123');
    console.log('  ADMIN:  admin@booknest.com / password123\n');

    process.exit(0);
  } catch (err) {
    console.error('❌ Seeding failed:', err);
    process.exit(1);
  }
}

seedTestData();
